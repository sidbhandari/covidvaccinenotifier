import { Component } from '@angular/core';
  import { shareTextToWhatsApp } from 'share-text-to-whatsapp';
import { shareTextViaNativeSharing } from 'share-text-to-whatsapp';
import { HttpClient, HttpHeaders, HttpClientModule, HttpParams } from '@angular/common/http';
import { interval } from 'rxjs'; 
import { Subscription, from } from 'rxjs';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
   providers: [DatePipe]
})
export class AppComponent {
  title = 'waapp';
  centerData:any;
sessions:any;
 filterArray: any[]=[];
 record_present:boolean=false;
subs: Subscription;
myDate:any;
 
 message = 'Hello world';



 constructor( public http: HttpClient,private datePipe: DatePipe){
    this.myDate = new Date();
 this.myDate = this.datePipe.transform(this.myDate, 'dd-MM-yyyy');

 console.log( this.myDate);
 
  this.getCowinData();
  this.refresh();


 }

 refresh(){
  
    this.subs = interval(10000)
      .subscribe((val) => {
this.filterArray=[];
        this.getCowinData();

      })

 }
share(){
  shareTextToWhatsApp(this.message); // This will open up WhatsApp and you will be shown a list of contacts you can send your message to.
}

 getCowinData() {

//https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/calendarByPin?pincode=411028&date=21-05-2021
  this.http.get('https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/calendarByDistrict?district_id=363&date='+this.myDate).subscribe(res => {

        console.log("Cowin Data", res);
    this.centerData=res['centers'];

    // console.log(this.centerData);
    
     this.centerData.filter((item) => {
   // console.log(item.pincode , item.name);

  if( (item.pincode ==411028 || item.pincode ==411011 || item.pincode ==411013 ) && (item.fee_type=='Paid' || item.fee_type=='Free' ) ){
//console.log(item.fee_type,item.name,item.pincode , data.available_capacity, data.date, data.vaccine);
    this.filterArray.push(item);  

}  
    /* 
item.sessions.filter((data) => {
  if(data.available_capacity>0 && (item.pincode ==411028 || item.pincode ==411011 || item.pincode ==411013 ) && item.fee_type=='Paid' && data.available_capacity_dose2>0){
console.log(item.fee_type,item.name,item.pincode , data.available_capacity, data.date, data.vaccine);

 this.record_present=true; 


}
  else{
    this.record_present=false;
  }

}); */

    });

   console.log(this.filterArray);  
   });
}
}

